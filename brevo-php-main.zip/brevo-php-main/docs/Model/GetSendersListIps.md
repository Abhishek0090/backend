# GetSendersListIps

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip** | **string** | Dedicated IP available in your account | 
**domain** | **string** | Domain of the IP | 
**weight** | **int** | Weight of the IP for this sender | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


