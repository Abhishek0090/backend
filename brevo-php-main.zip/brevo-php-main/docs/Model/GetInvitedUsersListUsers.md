# GetInvitedUsersListUsers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** | Email address of the user. | 
**isOwner** | **string** | Flag for indicating is user owner of the organization. | 
**status** | **string** | Status of the invited user. | 
**featureAccess** | [**\Brevo\Client\Model\GetInvitedUsersListFeatureAccess**](GetInvitedUsersListFeatureAccess.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


