# GetIpFromSender

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | ID of the dedicated IP | 
**ip** | **string** | Dedicated IP | 
**domain** | **string** | Domain associated to the IP | 
**weight** | **int** | Weight of the IP | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


