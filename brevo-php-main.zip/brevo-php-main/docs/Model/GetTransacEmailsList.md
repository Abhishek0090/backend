# GetTransacEmailsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Total number of transactional emails available on your account according to the passed filter | [optional] 
**transactionalEmails** | [**\Brevo\Client\Model\GetTransacEmailsListTransactionalEmails[]**](GetTransacEmailsListTransactionalEmails.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


