# AbTestCampaignResultStatistics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**openers** | [**\Brevo\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**clicks** | [**\Brevo\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**unsubscribed** | [**\Brevo\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**hardBounces** | [**\Brevo\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**softBounces** | [**\Brevo\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 
**complaints** | [**\Brevo\Client\Model\AbTestVersionStats**](AbTestVersionStats.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


