# GetChildInfoCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emailCredits** | **int** | Email credits available for your child | [optional] 
**smsCredits** | **int** | SMS credits available for your child | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


