# GetDomainsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domains** | [**\Brevo\Client\Model\GetDomainsListDomains[]**](GetDomainsListDomains.md) | List of the domains available in your account | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


