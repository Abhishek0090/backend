# SubAccountDetailsResponsePlanInfoFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inbox** | [**\Brevo\Client\Model\SubAccountDetailsResponsePlanInfoFeaturesInbox**](SubAccountDetailsResponsePlanInfoFeaturesInbox.md) |  | [optional] 
**landingPage** | [**\Brevo\Client\Model\SubAccountDetailsResponsePlanInfoFeaturesLandingPage**](SubAccountDetailsResponsePlanInfoFeaturesLandingPage.md) |  | [optional] 
**users** | [**\Brevo\Client\Model\SubAccountDetailsResponsePlanInfoFeaturesUsers**](SubAccountDetailsResponsePlanInfoFeaturesUsers.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


