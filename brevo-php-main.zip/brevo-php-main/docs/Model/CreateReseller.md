# CreateReseller

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authKey** | **string** | AuthKey of Reseller child created | 
**id** | **int** | Id of Reseller child created | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


