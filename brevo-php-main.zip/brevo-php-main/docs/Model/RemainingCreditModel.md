# RemainingCreditModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**child** | [**\Brevo\Client\Model\RemainingCreditModelChild**](RemainingCreditModelChild.md) |  | 
**reseller** | [**\Brevo\Client\Model\RemainingCreditModelReseller**](RemainingCreditModelReseller.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


