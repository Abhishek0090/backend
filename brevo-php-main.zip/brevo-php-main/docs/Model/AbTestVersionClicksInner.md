# AbTestVersionClicksInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**link** | **string** | URL of the link | 
**clicksCount** | **int** | Number of times a link is clicked | 
**clickRate** | **string** | Percentage of clicks of link with respect to total clicks | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


