# GetWATemplates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**\Brevo\Client\Model\GetWATemplatesTemplates[]**](GetWATemplatesTemplates.md) |  | 
**count** | **int** | Number of whatsApp templates retrived | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


