# GetAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attributes** | [**\Brevo\Client\Model\GetAttributesAttributes[]**](GetAttributesAttributes.md) | Listing of available contact attributes in your account | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


