# GetBlockedDomains

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domains** | **string[]** | List of all blocked domains | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


