# GetExtendedContactDetailsStatisticsClicked

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**campaignId** | **int** | ID of the campaign which generated the event | 
**links** | [**\Brevo\Client\Model\GetExtendedContactDetailsStatisticsLinks[]**](GetExtendedContactDetailsStatisticsLinks.md) | Listing of the clicked links for the campaign | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


