# SendReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **string** | Language of email content for campaign report sending. | [optional] [default to 'fr']
**email** | [**\Brevo\Client\Model\SendReportEmail**](SendReportEmail.md) |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


