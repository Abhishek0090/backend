from cProfile import run
import re
import random
from flask import Flask, request, render_template, session, redirect, url_for
from flask_session import Session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import pickle

# create an instance
app = Flask(__name__, template_folder='template')

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

app.static_folder = 'static'
app.secret_key = 'secret' 

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'admin'
app.config['MYSQL_DB'] = 'event'

mysql = MySQL(app)

@app.route('/')
def home():
    if not session.get("name"):
        return redirect('/login')
    return render_template('index.html')

events = pickle.load(open('./models/events2.pkl','rb'))
similarity = pickle.load(open('./models/similarity2.pkl','rb'))

def getFriend():
    user_id = session['id']
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT friend_id FROM friends WHERE user_id = % s', (user_id, ))
    account = cursor.fetchall()
    acc = []
    for i in account:
        temp = list(i.values())[0]
        acc.append(temp)
    return acc

def getRandomFriendid(acc):
    friendAc = random.choice(acc)
    return friendAc

def allUsers():
    all_users = []
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT username from users')
    all_users.append(cursor.fetchall())

    all_users = [item for sublist in all_users for item in sublist]
    for i in range(len(all_users)):
        all_users[i] = list(all_users[i].values())[0]   
    return all_users

def pending():
    pending = []
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT fr_reciever from followReq WHERE fr_sender = %s', (session['id'], ))
    pending.append(cursor.fetchall())

    pending = [item for sublist in pending for item in sublist]
    for i in range(len(pending)):
        pending[i] = list(pending[i].values())[0]

    usernamesPending = []
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT username from users where user_id = %s', (int(pending[0]), ))
    usernamesPending.append(cursor.fetchall())

    usernamesPending = [item for sublist in usernamesPending for item in sublist]
    for i in range(len(usernamesPending)):
        usernamesPending[i] = list(usernamesPending[i].values())[0]

    return usernamesPending

def recieved():
    recieved = []
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT fr_sender from followReq WHERE fr_reciever = %s', (session['id'], ))
    recieved.append(cursor.fetchall())
    return recieved
    
@app.route('/profile')
def profile():
    #Connecting friends
    user_id = session['id']
    friends = getFriend()   

    #Get username from user table 
    username = []
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

    for i in friends:
        temp = cursor.execute('SELECT username from users where user_id = %s', (int(i), ))
        # username.append(temp)
        username.append(cursor.fetchall())

    username = [item for sublist in username for item in sublist]

    for i in range(len(username)):
        username[i] = list(username[i].values())[0]   
    
    #All users
    all_users = allUsers()
    all_users.remove(session['username'])

    #Pending Requests
    pendingList = pending()

    #Recieved Requests
    recievedList = recieved()

    return render_template('profile.html', all_users=all_users, username=username, friends=friends, pending=pendingList, recieved = recievedList)

@app.route('/login', methods =['GET', 'POST'])
def login():
    msg = ''
    ses = None
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM users WHERE username = % s AND password = % s', (username, password, ))
        account = cursor.fetchone()

        if account:
            status = True
            session['loggedin'] = True
            session['id'] = account['user_id']
            session['username'] = account['username']
            msg = 'Logged in successfully !'
            return render_template('index.html', msg = msg, status = status)
        
        else:
            msg = 'Incorrect username / password !'
        
        ses = session['loggedin']
    return render_template('login.html', msg = msg, ses=ses)
 
@app.route('/movies' , methods = ["POST"])
def movies():
    ses = session['loggedin']
    if request.method == 'POST':
        event = request.form['movie']
        index = events[events['name'] == event].index[0]
        distances = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda x: x[1])
        recommended_event_names = []
        for i in distances[1:6]:
            event_id = events.iloc[i[0]].event_id
            recommended_event_names.append(events.iloc[i[0]]['name'])
        event_list = events['name'].values
        ans = list(recommended_event_names[:5])

        friends = getFriend()
        randomFriendId = int(getRandomFriendid(friends))

        randomFriendId = 1
        # # --------------------------------------------------

        friendsEvent = []
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT event_id FROM attendingEvent WHERE user_id = %s', (randomFriendId, ))
        TEMP = cursor.fetchall()
        for i in TEMP:
            temp = list(i.values())[0]
            friendsEvent.append(temp)

        # Getting a random event
        randomEventId = random.choice(friendsEvent)

        cursor.execute('SELECT event_name FROM allEvents WHERE event_id = %s', (randomEventId, ))

        FriendEvent = str(list(cursor.fetchone().values())[0])
        index = events[events['name'] == FriendEvent].index[0]
        distances = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda x: x[1])
        friends_recommended_event_names = []
        for i in distances[1:6]:
            event_id = events.iloc[i[0]].event_id
            friends_recommended_event_names.append(events.iloc[i[0]]['name'])
        event_list = events['name'].values
        ans = list(friends_recommended_event_names[:5])
        
        if isinstance(ans,list): return render_template('index.html', recommend = ans, ses=ses, friends = friends_recommended_event_names, temp = FriendEvent)
        else: return render_template('index.html', recommendSelf = ans, ses=ses, friends = friends_recommended_event_names, temp = FriendEvent)
        # if isinstance(ans,list): return render_template('index.html', recommend = ans, ses=ses)
        # else: return render_template('index.html', recommendSelf = ans, ses=ses)

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None) 
    return redirect(url_for('login'))

@app.route('/add/<username>')
def add(username):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT user_id FROM users WHERE username = %s', (username, ))
    user_id = cursor.fetchone()
    user_id = int(user_id['user_id'])
    print(session['id'], user_id)
    cursor2 = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    session['id'] = int(session['id'])
    cursor2.execute('INSERT INTO followReq VALUES (%s, %s)', (session['id'], user_id))
    mysql.connection.commit()

    #Required variables
    all_users = allUsers()
    username = session['username']
    friends = getFriend()
    pendingList = pending()
    recievedList = recieved()

    return render_template('index.html', all_users=all_users, username=username, friends=friends, pending=pendingList, recieved = recievedList)

@app.route('/accept')
def accept(username):
    # username = request.args.get()
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT user_id FROM users WHERE username = %s', (username, ))
    user_id = cursor.fetchone()

    user_id = user_id['user_id']

    cursor.execute('INSERT INTO friends (user1, user2) VALUES (%s, %s)', (session['id'], user_id))
    mysql.connection.commit()

    cursor.execute('DELETE FROM followReq WHERE fr_sender = %s AND fr_reciever = %s', (user_id, session['username']))

@app.route('/register', methods =['GET', 'POST'])
def register(): 
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
        
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM users WHERE username = % s', (username, ))
        account = cursor.fetchone()

        if account:
            msg = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address !'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers !'
        elif not username or not password or not email:
            msg = 'Please fill out the form !'
        else:
            cursor.execute('INSERT INTO users VALUES (NULL, % s, % s, % s)', (username, password, email, ))
            mysql.connection.commit()
            msg = 'You have successfully registered !'
    elif request.method == 'POST':
        msg = 'Please fill out the form !'
    return render_template('register.html', msg = msg)

app.run(debug=True)