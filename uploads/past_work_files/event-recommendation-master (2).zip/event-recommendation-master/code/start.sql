CREATE DATABASE event;
use event;
CREATE TABLE users( user_id INT NOT NULL PRIMARY KEY auto_increment, username VARCHAR(30) NOT NULL, password VARCHAR(30) NOT NULL, email VARCHAR(100) NOT NULL );
CREATE TABLE follow( user_id INT NOT NULL REFERENCES users(user_id), follow_id INT NOT NULL REFERENCES users(user_id) );
CREATE TABLE allEvent( event_id INT NOT NULL PRIMARY KEY auto_increment, eventName VARCHAR(200) NOT NULL );
CREATE TABLE eventReg( user_id INT NOT NULL REFERENCES users(user_id), event_id INT NOT NULL REFERENCES allEvent(event_id) );